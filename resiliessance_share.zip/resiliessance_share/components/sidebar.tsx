import {
  Bike,
  Brain,
  Car,
  CheckCircle2,
  FileCheck,
  GraduationCap,
  KanbanSquare,
  LayoutDashboard,
  PackageCheck,
  Wallet,
  BarChart,
  Dog,
  PlusCircle,
  Clock,
  Apple,
  Settings,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import Image from "next/image";

export default function Sidebar({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {

  return (
    <>
      <div
        onClick={onClose}
        className={`fixed inset-0 bg-black/55 z-50 transition-opacity duration-300 ${
          isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      />
      <nav
        aria-hidden={!isOpen}
        className={`fixed top-0 left-0 h-[100dvh] w-[min(230px,70vw)] bg-card border-r border-border/40 z-[60] transform transition-transform duration-500 ease-[cubic-bezier(0.23,1,0.32,1)] shadow-[20px_0_40px_rgba(0,0,0,0.05)] overflow-y-auto no-scrollbar ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >

        <div className="pt-6 px-5 pb-3 bg-card">
          <div className="flex items-center gap-2">
            <Image src="/logo.svg" alt="Resiliessance Logo" width={28} height={28} className="rounded-lg object-contain" />
            <div className="text-2xl font-black tracking-tighter text-foreground leading-none">
              Resiliessance
            </div>
          </div>
        </div>

        <ul className="list-none m-0 py-3 px-2.5 space-y-[9px]">
          {/* Dashboard */}
          <NavItem href="/" icon={<LayoutDashboard size={20} />} title="Dashboard" onClick={onClose} />
          {/* Reports */}
          <NavItem href="/reports/all" icon={<BarChart size={20} />} title="Reports" onClick={onClose} />
          {/* Quick Add */}
          <NavItem href="/quick-add" icon={<PlusCircle size={20} />} title="Quick Add" onClick={onClose} />
          {/* Activity Timeline */}
          <NavItem href="/activity-timeline" icon={<Clock size={20} />} title="Activity Timeline" onClick={onClose} />

          {/* Divider with breathable vertical spacing */}
          <div className="h-px bg-slate-100 my-[14px] mx-4" />

          {/* Finance */}
          <NavItem href="/finance/daily-entry?type=Expense" icon={<Wallet size={20} />} title="Finance" onClick={onClose} />

          {/* Habits */}
          <NavItem href="/habits/daily-log" icon={<CheckCircle2 size={20} />} title="Habits" onClick={onClose} />

          {/* Workout */}
          <NavItem href="/workout/logger" icon={<Bike size={20} />} title="Workout" onClick={onClose} />

          {/* Nutrition */}
          <NavItem href="/nutrition" icon={<Apple size={20} />} title="Nutrition" onClick={onClose} />

          {/* Pets & Vehicles */}
          <NavItem href="/pets" icon={<Dog size={20} />} title="Pets" onClick={onClose} />
          <NavItem href="/vehicles/fuel" icon={<Car size={20} />} title="Vehicles" onClick={onClose} />

          {/* Core Apps */}
          <NavItem href="/tasks" icon={<KanbanSquare size={20} />} title="Task Manager" onClick={onClose} />
          <NavItem href="/squareshift" icon={<FileCheck size={20} />} title="SquareShift" onClick={onClose} />
          <NavItem href="/skills" icon={<GraduationCap size={20} />} title="Skills" onClick={onClose} />
          
          {/* Second Brain */}
          <NavItem href="/second-brain" icon={<Brain size={20} />} title="Second Brain" onClick={onClose} />

          {/* Inventory */}
          <NavItem href="/inventory" icon={<PackageCheck size={20} />} title="Inventory" onClick={onClose} />

          {/* New Divider below Inventory */}
          <div className="h-px bg-slate-100 mt-[14px] mb-[6px] mx-4" />

          {/* Settings */}
          <NavItem href="/settings" icon={<Settings size={20} />} title="Settings" onClick={onClose} />
        </ul>

      </nav>
    </>
  );
}

function NavItem({ icon, title, onClick, href }: { icon: React.ReactNode; title: string; onClick?: () => void; href?: string }) {
  const pathname = usePathname();
  const basePath = href ? href.split('?')[0] : '';
  const isActive = href && (pathname === href || (href !== '/' && pathname.startsWith(basePath)));
  
  const content = (
    <div className={`flex items-center gap-3 py-2.5 px-3 rounded-xl text-[15px] font-bold cursor-pointer transition-all duration-300 select-none
      ${isActive ? "text-primary-foreground bg-primary shadow-xl shadow-primary/10 scale-[1.02]" : "text-muted-foreground hover:text-foreground hover:bg-muted"}
    `}>
      <div className="w-5 flex justify-center">{icon}</div>
      <span>{title}</span>
    </div>
  );

  return (
    <li onClick={onClick}>
      {href ? <Link href={href} prefetch>{content}</Link> : content}
    </li>
  );
}


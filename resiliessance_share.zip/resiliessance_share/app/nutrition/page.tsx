import { redirect } from "next/navigation";

export default function NutritionPage() {
  redirect("/nutrition/logs");
}

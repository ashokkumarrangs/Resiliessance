'use client'
import { Select } from "@/components/Select";;

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { Calendar, ChevronDown, ChevronRight, Plus, RefreshCw, Trash2, ChevronLeft} from "lucide-react";
import { getStatusIcon, getStatusStyles} from "@/lib/habit-ui-utils";
import { calculateHabitStatus, HabitStatus, sumDurations } from '@/lib/habit-scoring';
import { format, addDays, subDays } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';

import { HABIT_TABS } from "@/lib/navigation";
import { SubNav } from "@/components/SubNav";

import { toast } from 'sonner';
import { PageWrapper } from "@/components/PageWrapper";

interface HabitConfig {
  id: string;
  habit_name: string;
  group_name: string;
  input_type: string;
  unit: string;
  frequency: string;
  emoji: string;
  habit_color: string;
  condition_type?: string;
  direction?: string;
  suc_min?: number;
  suc_max?: number;
  target_value?: number;
}

interface EventAggregate {
  count: number;
  valueDisplay: string;
  lastValue: string;
  status: HabitStatus;
}


const EVENT_COLORS: Record<string, string> = {
  'alpha': 'bg-card border-border/40 text-foreground',
  'value': 'bg-primary/10 border-primary/20 text-primary',
  'count': 'bg-accent/10 border-accent/20 text-accent-foreground',
  'time': 'bg-muted border-border/40 text-foreground',
  'duration': 'bg-card border-border/40 text-foreground',
  'boolean': 'bg-primary/20 border-primary/40 text-primary',
  'default': 'bg-card border-border/40 text-foreground'
};

export default function HabitEventLogPage() {
  const router = useRouter();
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [eventConfigs, setEventConfigs] = useState<HabitConfig[]>([]);
  const [aggregates, setAggregates] = useState<Record<string, EventAggregate>>({});
  const [loading, setLoading] = useState(true);
  const [logging, setLogging] = useState<Record<string, boolean>>({});
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [rawEvents, setRawEvents] = useState<any[]>([]);

  // Form states for each card
  const [formNotes, setFormNotes] = useState<Record<string, string>>({});
  const [formTimes, setFormTimes] = useState<Record<string, string>>({});
  const [formValues, setFormValues] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchData();
  }, [selectedDate]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: configData, error: configError } = await supabase
        .from('habit_config')
        .select('*')
        .eq('is_paused', false)
        .eq('is_archived', false)
        .eq('is_deleted', false)
        .eq('frequency', 'event');

      if (configError) throw configError;
      setEventConfigs(configData || []);

      const times: Record<string, string> = {};
      const notes: Record<string, string> = {};
      const vals: Record<string, string> = {};

      (configData || []).forEach(c => {
        times[c.habit_name] = '';
        notes[c.habit_name] = '';
        vals[c.habit_name] = '';
      });
      setFormTimes(times);
      setFormNotes(notes);
      setFormValues(vals);

      const { data: eventData, error: eventError } = await supabase
        .from('event_log')
        .select('*')
        .eq('date', selectedDate)
        .order('created_at', { ascending: true });

      if (eventError) throw eventError;

      const aggs: Record<string, EventAggregate> = {};
      (eventData || []).forEach(e => {
        if (!aggs[e.event]) {
          aggs[e.event] = { count: 0, valueDisplay: '', lastValue: e.value, status: 'Not Entered' };
        }
        aggs[e.event].count++;
        
        const config = (configData || []).find(c => c.habit_name === e.event);
        if (config) {
          if (config.input_type === 'duration') {
            aggs[e.event].valueDisplay = sumDurations(aggs[e.event].valueDisplay, e.value);
          } else if (config.input_type === 'number') {
            const current = parseFloat(aggs[e.event].valueDisplay) || 0;
            aggs[e.event].valueDisplay = String(current + (parseFloat(e.value) || 0));
          } else {
            // Latest non-empty value for Text, Time, etc.
            if (e.value && e.value !== '1') {
              aggs[e.event].valueDisplay = e.value;
            } else if (!aggs[e.event].valueDisplay) {
              aggs[e.event].valueDisplay = e.value || '';
            }
          }
        }
      });

      // Calculate status for each aggregate
      Object.keys(aggs).forEach(hName => {
        const config = (configData || []).find(c => c.habit_name === hName);
        if (config) {
          let scoreValue = aggs[hName].valueDisplay;
          if (config.input_type === 'text') {
            scoreValue = String(aggs[hName].count);
          }
          aggs[hName].status = calculateHabitStatus(config, scoreValue);
        }
      });

      setRawEvents(eventData || []);
      setAggregates(aggs);
    } catch (err: any) {
      console.error('Event Log Fetch Error:', err);
      toast.error(err.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const syncEventDayToHabitData = async (habitName: string, dateStr: string) => {
    try {
      // 1. Fetch config to know how to aggregate
      const { data: configData } = await supabase.from('habit_config').select('*').eq('habit_name', habitName).single();
      if (!configData) return;

      // 2. Fetch all events for that day
      const { data: events } = await supabase.from('event_log').select('*').eq('event', habitName).eq('date', dateStr);
      
      if (!events || events.length === 0) {
        // Delete the roll-up if no events exist
        await supabase.from('habit_data').delete().eq('habit', habitName).eq('date', dateStr);
        return;
      }

      // 3. Aggregate
      let aggValue = '0';
      const isCount = configData.condition_type.endsWith('_count') || ['text', 'time', 'boolean'].includes(configData.input_type);
      
      if (isCount) {
        aggValue = String(events.length);
      } else if (configData.input_type === 'number') {
        const sum = events.reduce((acc, e) => acc + (parseFloat(e.value) || 0), 0);
        aggValue = String(sum);
      } else if (configData.input_type === 'duration') {
        aggValue = events.reduce((acc, e) => sumDurations(acc, e.value || '00:00'), '00:00');
      }

      // 4. Calculate Final Status
      const scoringConfig = { ...configData };
      if (isCount) {
         scoringConfig.input_type = 'number'; // The engine should treat the count as a number
      }
      
      const finalStatus = calculateHabitStatus(scoringConfig, aggValue);

      // 5. Upsert to habit_data
      const { data: existingData } = await supabase.from('habit_data').select('id').eq('habit', habitName).eq('date', dateStr).maybeSingle();
      if (existingData) {
         await supabase.from('habit_data').update({ value: aggValue, status: finalStatus, notes: 'Aggregated from events' }).eq('id', existingData.id);
      } else {
         await supabase.from('habit_data').insert({
            date: dateStr,
            habit: habitName,
            value: aggValue,
            status: finalStatus,
            notes: 'Aggregated from events'
         });
      }
    } catch (err: any) {
      console.error("Failed to sync event to habit_data", err);
    }
  };

  const handleDeleteEvent = async (id: number) => {
    try {
      const { error } = await supabase.from('event_log').delete().eq('id', id);
      if (error) throw error;
      toast.success('Event log deleted!');
      const deletedEvent = rawEvents.find(e => e.id === id);
      if (deletedEvent) await syncEventDayToHabitData(deletedEvent.event, deletedEvent.date);
      fetchData();
    } catch (err: any) {
      toast.error(err.message || 'Failed to delete event log');
    }
  };



  const handleLogEvent = async (habitName: string) => {
    const config = eventConfigs.find(c => c.habit_name === habitName);
    if (!config) return;

    const val = formValues[habitName];
    if ((config.input_type === 'number' || config.input_type === 'duration' || config.input_type === 'time') && (!val || val.trim() === '')) {
      toast.error(`Please enter a valid ${config.input_type} value`);
      return;
    }

    setLogging(prev => ({ ...prev, [habitName]: true }));
    try {
      const logVal = val || (config.input_type === 'boolean' || config.input_type === 'number' ? '1' : '');
      const time = formTimes[habitName] || format(new Date(), 'HH:mm');
      const note = formNotes[habitName];

      const { error: logError } = await supabase.from('event_log').insert({
        date: selectedDate,
        time: time,
        event: habitName,
        value: String(logVal),
        note: note
      });

      if (logError) throw logError;

      toast.success(`${habitName} logged!`);
      await syncEventDayToHabitData(habitName, selectedDate);
      // Reset only value and note
      setFormNotes(prev => ({ ...prev, [habitName]: '' }));
      setFormValues(prev => ({ ...prev, [habitName]: '' }));
      fetchData();
    } catch (err: any) {
      console.error('Event Log Save Error:', err);
      toast.error(err.message || 'Failed to log event');
    } finally {
      setLogging(prev => ({ ...prev, [habitName]: false }));
    }
  };

  return (
    <PageWrapper
      title="Event Log"
      reportHref="/reports/habits"
      sectionTabs={HABIT_TABS}
      activePath="/habits/daily-log"
    >
        
        
        <SubNav 
          items={["Daily Log", "Event Log", "Off-Day Habits"]}
          activeItem="Event Log"
          onChange={(val) => {
            if (val === "Daily Log") router.push("/habits/daily-log");
            if (val === "Off-Day Habits") router.push("/habits/daily-log?tab=off-day");
          }}
        />

        {/* Date Swapper */}
        <div className="flex justify-center mb-6 mt-6 w-full">
          <div className="bg-card px-4 py-1.5 rounded-xl border border-border/40 shadow-sm flex items-center justify-between w-full max-w-sm">
             <button 
               onClick={() => setSelectedDate(prev => format(subDays(new Date(prev), 1), 'yyyy-MM-dd'))}
               className="p-2 hover:bg-muted rounded-lg transition-colors text-muted-foreground hover:text-foreground"
             >
                <ChevronLeft size={16} />
             </button>
             <div className="flex items-center gap-2 font-black text-xs text-foreground uppercase tracking-tight">
                <Calendar className="w-3.5 h-3.5 text-primary opacity-50" />
                <input 
                  type="date" 
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="bg-transparent border-none focus:ring-0 cursor-pointer font-black text-center text-sm text-foreground"
                />
             </div>
             <button 
               onClick={() => setSelectedDate(prev => format(addDays(new Date(prev), 1), 'yyyy-MM-dd'))}
               className="p-2 hover:bg-muted rounded-lg transition-colors text-muted-foreground hover:text-foreground"
             >
                <ChevronRight size={16} />
             </button>
          </div>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3, 4].map(i => <div key={i} className="h-28 bg-muted animate-pulse rounded-[1.5rem]" />)}
          </div>
        ) : (
          <div className="space-y-4">
            {eventConfigs.map(habit => {
              const colorKey = habit.habit_name.toLowerCase().includes('sleep') ? 'value' : 
                               habit.habit_name.toLowerCase().includes('count') ? 'count' :
                               habit.habit_name.toLowerCase().includes('time') ? 'time' :
                               habit.habit_name.toLowerCase().includes('duration') ? 'duration' :
                               habit.habit_name.toLowerCase().includes('boolean') ? 'boolean' : 'default';
              
              const colorClasses = EVENT_COLORS[colorKey] || EVENT_COLORS['default'];
              const agg = aggregates[habit.habit_name] || { count: 0, valueDisplay: '', status: 'Not Entered' as HabitStatus };
              const styles = getStatusStyles(agg.status);

              return (
                <Card key={habit.habit_name} className={`rounded-md border shadow-zenith overflow-hidden transition-all active:scale-[0.99] ${colorClasses} ${styles.bg} ${styles.anim}`}>
                  <CardContent className="p-5 flex flex-col gap-4">
                    {/* Header Row */}
                      <div className="flex justify-between items-center">
                         <h2 className={`text-xl tracking-tighter flex items-center gap-2 transition-all ${styles.text} ${styles.weight}`}>
                            <span className="text-2xl">{habit.emoji}</span>
                            <div className="flex flex-col justify-start">
                              <div className="flex items-center gap-2">
                                {habit.habit_name}
                                <div className="ml-1">
                                   {getStatusIcon(agg.status, 20)}
                                </div>
                              </div>
                              <div className="text-[10px] text-muted-foreground/50 font-bold mt-0.5 normal-case tracking-normal">
                                Target: {(() => {
                                  const isEvent = habit.frequency === 'event';
                                  const isCount = isEvent && habit.condition_type?.endsWith('_count');
                                  let baseCond = isCount ? (habit.condition_type || '').replace('_count', '') : habit.condition_type;
                                  
                                  let suffix = habit.unit ? ` ${habit.unit}` : '';
                                  if (isEvent) {
                                    if (isCount) {
                                      suffix = ' times';
                                    } else {
                                      suffix = habit.unit ? ` ${habit.unit} (Sum)` : ' (Sum)';
                                    }
                                  }
                                  
                                  if (baseCond === 'above_below') {
                                    baseCond = habit.direction === 'less' ? 'at_most_n' : 'at_least_n';
                                  }
                                  
                                  if (habit.input_type === 'boolean') {
                                    return habit.target_value === 0 ? 'No' : 'Yes';
                                  }
                                  if (baseCond === 'between') {
                                    return `Between ${habit.suc_min} and ${habit.suc_max}${suffix}`;
                                  }
                                  if (baseCond === 'at_least_n') {
                                    return `At least ${habit.target_value}${suffix}`;
                                  }
                                  if (baseCond === 'at_most_n') {
                                    return `At most ${habit.target_value}${suffix}`;
                                  }
                                  if (baseCond === 'exactly_n') {
                                    return `Exactly ${habit.target_value}${suffix}`;
                                  }
                                  return `${habit.target_value}${suffix}`;
                                })()}
                              </div>
                            </div>
                        </h2>
                        <div className="flex items-center gap-2 shrink-0">
                           <div className="h-8 min-w-[36px] px-2 flex items-center justify-center bg-card text-foreground border border-border/40 rounded-md text-xs font-black shadow-sm">
                             {agg.count}
                          </div>
                          <div className={`h-8 min-w-[40px] px-2.5 flex items-center justify-center rounded-md border border-border/40 text-xs font-black tracking-wider shadow-sm ${colorKey === 'count' || colorKey === 'boolean' ? 'bg-primary/20 text-primary border-primary/10' : 'bg-muted text-foreground'}`}>
                             {agg.valueDisplay || (habit.input_type === 'text' ? '--' : '0')}{habit.input_type !== 'text' && habit.unit ? ` ${habit.unit}` : ''}
                          </div>
                       </div>
                    </div>


                     {/* Dynamic Input Area */}
                      <div className="flex items-end gap-2.5 min-h-[50px] w-full">
                         <div className="w-[70px] flex flex-col justify-end">
                            <label className="text-[9px] font-black uppercase opacity-30 mb-1 ml-1 leading-none">Time</label>
                            <Input 
                              type="time"
                              value={formTimes[habit.habit_name] || ''}
                              onChange={(e) => setFormTimes(prev => ({ ...prev, [habit.habit_name]: e.target.value }))}
                              className="bg-muted/50 border-none h-9 min-h-[36px] rounded-md font-bold text-center py-0 px-1 text-foreground text-xs"
                            />
                         </div>

                         <div className="flex-[2] flex flex-col justify-end">
                            <label className="text-[9px] font-black uppercase opacity-30 mb-1 ml-1 leading-none">Notes</label>
                            <Input 
                              placeholder="Details..." 
                              value={formNotes[habit.habit_name] || ''}
                              onChange={(e) => setFormNotes(prev => ({ ...prev, [habit.habit_name]: e.target.value }))}
                              className="bg-muted/50 border-none h-9 min-h-[36px] rounded-md font-bold shadow-inner placeholder:text-muted-foreground/30 text-foreground text-xs py-0 px-2"
                            />
                         </div>

                         {habit.input_type === 'boolean' ? (
                           <div className="flex-1 flex flex-col justify-end">
                              <label className="text-[9px] font-black uppercase opacity-30 mb-1 ml-1 leading-none">Value</label>
                              <div className="relative group">
                                <Select 
                                  value={formValues[habit.habit_name] || 'Yes'} 
                                  onChange={(e) => setFormValues(prev => ({ ...prev, [habit.habit_name]: e.target.value }))}
                                  className="w-full h-9 min-h-[36px] bg-muted border border-border/40 rounded-md px-3 text-xs font-bold text-foreground focus:ring-2 focus:ring-primary/10 shadow-sm transition-all py-0"
                                >
                                  <option value="Yes">Yes</option>
                                  <option value="No">No</option>
                                </Select>
                              </div>
                           </div>
                         ) : (
                           <div className="flex-1 flex flex-col justify-end relative">
                              <label className="text-[9px] font-black uppercase opacity-30 mb-1 ml-1 leading-none">
                                {habit.input_type === 'time' ? 'Time' : habit.input_type === 'duration' ? 'Duration' : 'Value'}
                              </label>
                              <Input 
                                type={habit.input_type === 'time' || habit.input_type === 'duration' ? 'time' : habit.input_type === 'number' ? 'number' : 'text'} 
                                placeholder={habit.input_type === 'text' ? 'Enter...' : habit.input_type === 'duration' ? 'HH:MM' : '0'}
                                value={formValues[habit.habit_name] || ''}
                                onChange={(e) => setFormValues(prev => ({ ...prev, [habit.habit_name]: e.target.value }))}
                                inputMode={habit.input_type === 'number' ? 'decimal' : undefined}
                                className="bg-muted/50 border-none h-9 min-h-[36px] rounded-md font-black text-center shadow-inner text-foreground placeholder:text-muted-foreground/20 text-xs py-0 px-1"
                              />
                           </div>
                         )}

                         <Button 
                            onClick={() => handleLogEvent(habit.habit_name)}
                            disabled={logging[habit.habit_name]}
                            className="flex-1 h-9 min-h-[36px] py-0 rounded-md bg-primary hover:bg-primary/90 shadow-lg text-primary-foreground font-black text-xs active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 uppercase tracking-tighter"
                         >
                            {logging[habit.habit_name] ? <RefreshCw className="animate-spin w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                            ADD
                         </Button>
                      </div>

                     {/* Log List Section */}
                     {rawEvents.filter(e => e.event === habit.habit_name).length > 0 && (
                       <div className="mt-4 border-t border-border/20 pt-4 space-y-2">
                          <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground opacity-60">Today's Logs</div>
                          <div className="max-h-32 overflow-y-auto space-y-1.5 pr-1">
                             {rawEvents.filter(e => e.event === habit.habit_name).map((log) => (
                               <div key={log.id} className="flex items-center justify-between text-xs font-bold bg-muted/30 p-2 rounded-lg border border-border/10">
                                  <div className="flex items-center gap-2">
                                     <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded font-mono">{log.time ? log.time.substring(0, 5) : '--:--'}</span>
                                     <span className="text-foreground">{log.value} {habit.unit}</span>
                                     {log.note && <span className="text-muted-foreground opacity-70 italic font-normal">— {log.note}</span>}
                                  </div>
                                  <button 
                                    onClick={() => handleDeleteEvent(log.id)}
                                    className="text-muted-foreground hover:text-destructive p-1 rounded-md transition-colors"
                                    title="Delete log"
                                  >
                                     <Trash2 size={12} />
                                  </button>
                               </div>
                             ))}
                          </div>
                       </div>
                     )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <div className="py-10 flex flex-col items-center gap-4">
            <Button 
                variant="ghost" 
                onClick={() => router.push('/habits/daily-log')}
                className="group font-black uppercase tracking-widest text-foreground flex items-center gap-2 hover:bg-muted p-6 rounded-md transition-all"
            >
               Habit Tracker <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <div className="text-[10px] font-bold text-muted-foreground/20 uppercase tracking-[0.2em]">End of Active Stream</div>
        </div>
    </PageWrapper>
  );
}
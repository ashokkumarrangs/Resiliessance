import { redirect } from 'next/navigation';

export default function TasksRedirect() {
  redirect('/tasks/inbox');
}

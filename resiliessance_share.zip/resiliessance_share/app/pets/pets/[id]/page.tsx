"use client";
import React, { useState, useEffect, use } from "react";
import { PageWrapper } from "@/components/PageWrapper";
import { PET_TABS } from "@/lib/navigation";
import { SubNav } from "@/components/SubNav";
import { supabase } from "@/lib/supabase";
import { format, differenceInYears, differenceInMonths } from "date-fns";
import { Dog, PlusCircle, Activity, Sparkles, Trees, Shield, GraduationCap, Trash2, Tag, ListTodo, CalendarDays, Clock, FileText } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { SearchableSelect } from "@/components/SearchableSelect";
import { SaveButton } from "@/components/ui/SaveButton";
import { useDialog } from "@/components/dialog-provider";
const DEFAULT_CATEGORIES: Record<string, string[]> = {
  Grooming: ['Bath', 'Nail Trim', 'Teeth Brushing', 'Ear Cleaning', 'Haircut', 'Coat Brushing'],
  Activities: ['Beach Trip', 'Park Visit', 'Hike', 'Playdate', 'Swimming', 'Long Car Ride', 'Time Apart'],
  Wellness: ['Flea/Tick Meds', 'Heartworm Meds', 'Vomit / Upset Stomach', 'Vaccination', 'Deworming', 'Checkup'],
  Training: ['Training Session', 'Behavioral Incident', 'Separation Training']
};

export default function PetDashboard({ params }: { params: Promise<{ id: string }> }) {
  const router = useRouter();
  const { confirm } = useDialog();
  const { id: petId } = use(params);
  
  const [loading, setLoading] = useState(true);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [petData, setPetData] = useState<any>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [logsData, setLogsData] = useState<any[]>([]);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [allPets, setAllPets] = useState<any[]>([]);

  // Entry Form State
  const [entryCategory, setEntryCategory] = useState("Grooming");
  const [entrySubCategory, setEntrySubCategory] = useState("");
  const [entryDate, setEntryDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [entryTime, setEntryTime] = useState(format(new Date(), "HH:mm"));
  const [entryNotes, setEntryNotes] = useState("");
  const [entryNextDate, setEntryNextDate] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);


  // Dynamic Options state
  const [dynamicOptions, setDynamicOptions] = useState<Record<string, string[]>>(DEFAULT_CATEGORIES);

  useEffect(() => {
    if (petId) fetchDashboardData();
  }, [petId]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const { data: profile, error: profileErr } = await supabase.from('pet_profile').select('*').eq('id', petId).single();
      if (profileErr || !profile) {
        toast.error("Pet not found");
        router.push("/pets");
        return;
      }
      setPetData(profile);

      const { data: petLogs } = await supabase.from('pet_logs').select('*').eq('pet_id', petId).order('date', { ascending: false });
      const { data: allPetsData } = await supabase.from('pet_profile').select('*');
      if (allPetsData) setAllPets(allPetsData);
      if (petLogs) {
        setLogsData(petLogs);
        
        // Build dynamic options from past logs
        const newOptions = JSON.parse(JSON.stringify(DEFAULT_CATEGORIES));
        petLogs.forEach((log) => {
           if (log.category && log.log_type) {
              if (!newOptions[log.category]) newOptions[log.category] = [];
              if (!newOptions[log.category].includes(log.log_type)) {
                 newOptions[log.category].push(log.log_type);
              }
           }
        });
        setDynamicOptions(newOptions);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const calculateAge = (dobString: string) => {
    if (!dobString) return "Unknown Age";
    const dob = new Date(dobString);
    const today = new Date();
    const years = differenceInYears(today, dob);
    const months = differenceInMonths(today, dob) % 12;
    if (years === 0) return `${months} Months`;
    return `${years} Years, ${months} Months`;
  };

  const handleUnifiedSubmit = async () => {
    if (!entryCategory || !entrySubCategory || !entryDate) {
      toast.error("Category, Subcategory, and Date are required!");
      return;
    }
    
    setIsSubmitting(true);
    try {
       // eslint-disable-next-line @typescript-eslint/no-explicit-any
       const payload: any = {
          pet_id: petId,
          category: entryCategory,
          log_type: entrySubCategory,
          date: entryDate,
          time: entryTime,
          notes: entryNotes,
       };

       if (entryCategory === 'Wellness' && entryNextDate) {
          payload.next_due_date = entryNextDate;
       }

       const { error } = await supabase.from('pet_logs').insert(payload);
       if (error) {
          console.error("Supabase pet log insert error:", error);
          toast.error("Failed to save pet log. Please try again.");
          return;
       }
       toast.success("Entry logged successfully!");
       
       // Reset form
       setEntrySubCategory("");
       setEntryNotes("");
       setEntryNextDate("");
       setEntryTime(format(new Date(), "HH:mm"));

       fetchDashboardData();
    } catch (e) {
       toast.error("An error occurred");
    } finally {
       setIsSubmitting(false);
    }
  };

  const handleDeletePet = async () => {
    if (await confirm("Are you sure you want to delete this pet? This action cannot be undone.")) {
      const { error } = await supabase.from('pet_profile').delete().eq('id', petId);
      if (error) {
        toast.error("Failed to delete pet.");
      } else {
        toast.success("Pet deleted.");
        router.push("/pets");
      }
    }
  };

  const handleDeleteLog = async (logId: string) => {
    if (await confirm("Delete this log entry?")) {
      const { error } = await supabase.from('pet_logs').delete().eq('id', logId);
      if (error) {
        toast.error("Failed to delete log.");
      } else {
        toast.success("Log deleted.");
        fetchDashboardData();
      }
    }
  };

  if (loading) return <div className="flex h-screen items-center justify-center font-black animate-pulse">LOADING PROFILE...</div>;
  if (!petData) return null;

  const currentOptions = dynamicOptions[entryCategory] || [];

  return (
    <PageWrapper
      title={petData.name}
      reportHref="/reports/pets"
      sectionTabs={PET_TABS}
      activePath="/pets/pets"
      className="pb-20"
    >
        
        <div className="flex items-center justify-center relative mb-6 w-full">
          <SubNav 
            items={allPets.map(p => p.name)}
            activeItem={petData.name}
            onChange={(val) => {
              const p = allPets.find(x => x.name === val);
              if (p) router.push(`/pets/pets/${p.id}`);
            }}
            className="!mb-0 !mx-0"
          />
        </div>
        
        <div className="space-y-6 w-full">
          {/* Profile Card */}
          <div className="bg-gradient-to-r from-primary to-accent/80 rounded-3xl p-6 text-white shadow-xl flex items-center gap-6 relative overflow-hidden">
             <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
             <div className="absolute bottom-0 left-10 w-24 h-24 bg-black/10 rounded-full -mb-10 blur-lg"></div>
             <div className="w-24 h-24 bg-white/20 backdrop-blur-md rounded-full border-4 border-white/30 flex items-center justify-center shrink-0 shadow-inner z-10">
               {petData.species === 'Cat' ? <Activity size={40} className="text-white"/> : <Dog size={40} className="text-white" />}
             </div>
             <div className="z-10 flex-1">
               <h2 className="text-3xl font-black mb-1 drop-shadow-md">{petData.name}</h2>
               <p className="font-bold text-white/90 text-sm tracking-wide uppercase">{petData.breed || petData.species}</p>
               <p className="text-sm font-semibold mt-1 bg-black/20 inline-block px-3 py-1 rounded-full">{calculateAge(petData.dob)}</p>
             </div>
             <button onClick={handleDeletePet} className="absolute top-4 right-4 z-20 p-2 bg-black/20 hover:bg-black/40 text-white rounded-full transition-all" title="Delete Pet">
               <Trash2 size={16} />
             </button>
          </div>

          {/* UNIFIED ENTRY CARD */}
          <div className="bg-card border border-border/40 rounded-3xl p-6 shadow-xl relative overflow-hidden">
             <div className="flex items-center gap-2 mb-6">
                <PlusCircle className="text-primary" size={24} />
                <h3 className="text-2xl font-black">New Log Entry</h3>
             </div>

             <div className="space-y-4 relative z-10 w-full min-w-0">
                {/* Row 1: Category & Sub-Category */}
                <div className="grid grid-cols-2 gap-4 relative z-30">
                  <div className="space-y-2">
                    <SearchableSelect 
                      label="Category"
                      headerIcon={<Tag size={16} className="shrink-0" />}
                      value={entryCategory}
                      onChange={val => { setEntryCategory(val); setEntrySubCategory(""); }}
                      options={['Grooming', 'Activities', 'Wellness', 'Training']}
                    />
                  </div>
                  <div className="space-y-2">
                    <SearchableSelect
                       label="Sub-Category"
                       headerIcon={<ListTodo size={16} className="shrink-0" />}
                       options={currentOptions}
                       value={entrySubCategory}
                       onChange={setEntrySubCategory}
                       placeholder={`Select/Type...`}
                       createLabel="Create: {search}"
                    />
                  </div>
                </div>

                {/* Row 2: Date & Time */}
                <div className="grid grid-cols-2 gap-4 relative z-20">
                  <div className="space-y-2">
                    <label className="text-sm font-black text-muted-foreground/60 flex items-center gap-1.5 leading-none">
                      <CalendarDays size={16} className="shrink-0" />
                      {entryCategory === 'Wellness' ? 'Administered Date' : 'Date'}
                    </label>
                    <input 
                       type="date" 
                       value={entryDate} 
                       onChange={e => setEntryDate(e.target.value)} 
                       className="w-full min-w-0 bg-muted p-3 h-11 rounded-xl font-bold focus:outline-none focus:ring-2 focus:ring-primary/20 shadow-sm text-sm" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-black text-muted-foreground/60 flex items-center gap-1.5 leading-none">
                      <Clock size={16} className="shrink-0" />
                      Time
                    </label>
                    <input 
                       type="time" 
                       value={entryTime} 
                       onChange={e => setEntryTime(e.target.value)} 
                       className="w-full min-w-0 bg-muted p-3 h-11 rounded-xl font-bold focus:outline-none focus:ring-2 focus:ring-primary/20 shadow-sm text-sm text-center px-1" 
                    />
                  </div>
                </div>
             </div>

                {/* Next Planned Date (Conditional) */}
                {entryCategory === 'Wellness' && (
                  <div className="animate-in slide-in-from-top-2 fade-in bg-rose-500/5 p-4 rounded-xl border border-rose-500/10">
                    <label className="text-sm font-black text-rose-500 flex items-center gap-1.5 leading-none mb-2">
                       <Shield size={16} className="shrink-0" /> Next Due / Planned Date
                    </label>
                    <input 
                       type="date" 
                       value={entryNextDate} 
                       onChange={e => setEntryNextDate(e.target.value)} 
                       className="w-full bg-card p-3 rounded-xl font-bold focus:outline-none border shadow-sm focus:border-rose-500/50" 
                    />
                    <p className="text-[10px] text-muted-foreground mt-2 font-semibold">Leave blank if this was a one-time event (like an upset stomach).</p>
                  </div>
                )}

                {/* Notes */}
                <div className="mt-5 space-y-2">
                   <label className="text-sm font-black text-muted-foreground/60 flex items-center gap-1.5 leading-none">
                     <FileText size={16} className="shrink-0" />
                     Notes (Optional)
                   </label>
                   <textarea 
                     value={entryNotes} 
                     onChange={e => setEntryNotes(e.target.value)} 
                     placeholder="How did they do? Any details to remember?" 
                     className="w-full bg-muted p-4 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-primary/20 shadow-sm min-h-[100px]"
                   />
                </div>

                 <div className="flex justify-center pt-6">
                   <SaveButton 
                     onClick={handleUnifiedSubmit}
                     isSaving={isSubmitting}
                     label="Save Entry"
                     className="w-full max-w-xs h-11 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md font-bold text-sm shadow"
                   />
                 </div>
              </div>
          
          {/* Recent History Preview */}
          <div className="px-2">
             <h4 className="font-bold text-sm text-muted-foreground uppercase tracking-widest mb-4">Recent Entries</h4>
             {logsData.slice(0, 5).map((log) => (
                <div key={log.id} className="flex items-center gap-4 mb-3 bg-card p-3 rounded-2xl border shadow-sm">
                   <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-muted-foreground shrink-0">
                      {log.category === 'Grooming' && <Sparkles size={16} />}
                      {log.category === 'Activities' && <Trees size={16} />}
                      {log.category === 'Wellness' && <Shield size={16} />}
                      {log.category === 'Training' && <GraduationCap size={16} />}
                   </div>
                   <div className="flex-1 min-w-0">
                      <div className="font-bold truncate text-sm">{log.log_type}</div>
                      <div className="text-xs text-muted-foreground">{format(new Date(log.date + 'T12:00:00'), 'MMM dd, yyyy')}</div>
                   </div>
                   {log.category === 'Wellness' && log.next_due_date && (
                      <div className="text-right">
                         <div className="text-[9px] font-black uppercase text-rose-500">Next</div>
                         <div className="text-xs font-bold">{format(new Date(log.next_due_date), 'MMM dd')}</div>
                      </div>
                   )}
                   <button onClick={() => handleDeleteLog(log.id)} className="p-2 text-muted-foreground/30 hover:text-rose-500 hover:bg-rose-500/10 rounded-full transition-all shrink-0 ml-1">
                     <Trash2 size={14} />
                   </button>
                </div>
             ))}
          </div>

        </div>
    </PageWrapper>
  );
}

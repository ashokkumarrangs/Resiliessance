import { DM_Sans } from "next/font/google";
import "./globals.css";
import { cn } from "@/lib/utils";
import Shell from "@/components/shell";

const dmSans = DM_Sans({ 
  subsets: ["latin", "latin-ext"], 
  variable: "--font-dm-sans",
  weight: ["300", "400", "500", "600", "700", "800", "900"]
});

export const metadata = {
  title: "Resiliessance — Life OS",
  description: "Comprehensive personal operating system for habits, finance, workout, nutrition, tasks, and vehicles.",
  openGraph: {
    title: "Resiliessance — Life OS",
    description: "Comprehensive personal operating system for habits, finance, workout, nutrition, tasks, and vehicles.",
    type: "website",
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

import { Toaster } from "sonner";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" data-theme="ocean" suppressHydrationWarning className={cn("antialiased", dmSans.variable)}>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem("resiliessance_ui_theme")||"ocean";document.documentElement.setAttribute("data-theme",t);}catch(e){}})()`,
          }}
        />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/logo.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/icon-192.png" />
      </head>
      <body className="bg-background sm:shadow-2xl sm:max-w-md md:max-w-2xl lg:max-w-4xl xl:max-w-5xl sm:mx-auto min-h-screen">
        <Shell>{children}</Shell>
        <Toaster position="top-center" richColors />
      </body>

    </html>
  );
}

